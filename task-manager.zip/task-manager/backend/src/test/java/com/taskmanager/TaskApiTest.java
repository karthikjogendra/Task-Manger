package com.taskmanager;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class TaskApiTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper om;

    private String register(String username) throws Exception {
        String body = om.writeValueAsString(Map.of(
                "username", username, "email", username + "@example.com", "password", "secret123"));
        String res = mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return "Bearer " + om.readTree(res).get("token").asText();
    }

    private String taskJson(String title) throws Exception {
        return om.writeValueAsString(Map.of("title", title, "priority", "HIGH"));
    }

    @Test
    void requestsWithoutTokenAreRejected() throws Exception {
        mvc.perform(get("/api/tasks")).andExpect(status().isUnauthorized());
    }

    @Test
    void loginFailsWithWrongPassword() throws Exception {
        register("alice");
        String body = om.writeValueAsString(Map.of("username", "alice", "password", "wrong-pass"));
        mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void duplicateUsernameIsRejected() throws Exception {
        register("bob");
        String body = om.writeValueAsString(Map.of(
                "username", "bob", "email", "other@example.com", "password", "secret123"));
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isConflict());
    }

    @Test
    void fullCrudFlow() throws Exception {
        String auth = register("carol");

        String created = mvc.perform(post("/api/tasks").header("Authorization", auth)
                        .contentType(MediaType.APPLICATION_JSON).content(taskJson("Write report")))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("TODO"))
                .andReturn().getResponse().getContentAsString();
        long id = om.readTree(created).get("id").asLong();

        mvc.perform(get("/api/tasks").header("Authorization", auth))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].title").value("Write report"));

        String update = om.writeValueAsString(Map.of("title", "Write report", "status", "DONE"));
        mvc.perform(put("/api/tasks/" + id).header("Authorization", auth)
                        .contentType(MediaType.APPLICATION_JSON).content(update))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("DONE"));

        mvc.perform(delete("/api/tasks/" + id).header("Authorization", auth))
                .andExpect(status().isNoContent());
        mvc.perform(get("/api/tasks/" + id).header("Authorization", auth))
                .andExpect(status().isNotFound());
    }

    @Test
    void blankTitleFailsValidation() throws Exception {
        String auth = register("dave");
        mvc.perform(post("/api/tasks").header("Authorization", auth)
                        .contentType(MediaType.APPLICATION_JSON).content(taskJson("  ")))
                .andExpect(status().isBadRequest());
    }

    @Test
    void usersCannotAccessEachOthersTasks() throws Exception {
        String erin = register("erin");
        String frank = register("frank");

        String created = mvc.perform(post("/api/tasks").header("Authorization", erin)
                        .contentType(MediaType.APPLICATION_JSON).content(taskJson("Private")))
                .andReturn().getResponse().getContentAsString();
        long id = om.readTree(created).get("id").asLong();

        mvc.perform(get("/api/tasks/" + id).header("Authorization", frank))
                .andExpect(status().isNotFound());
    }
}
