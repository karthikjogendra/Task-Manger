package com.taskmanager.service;

import com.taskmanager.dto.TaskRequest;
import com.taskmanager.dto.TaskResponse;
import com.taskmanager.exception.ResourceNotFoundException;
import com.taskmanager.model.Priority;
import com.taskmanager.model.Task;
import com.taskmanager.model.TaskStatus;
import com.taskmanager.model.User;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class TaskService {

    private static final Logger log = LoggerFactory.getLogger(TaskService.class);

    private final TaskRepository tasks;
    private final UserRepository users;

    public TaskService(TaskRepository tasks, UserRepository users) {
        this.tasks = tasks;
        this.users = users;
    }

    @Transactional(readOnly = true)
    public List<TaskResponse> list(String username, TaskStatus status) {
        User owner = owner(username);
        List<Task> found = status == null
                ? tasks.findByOwnerOrderByCreatedAtDesc(owner)
                : tasks.findByOwnerAndStatusOrderByCreatedAtDesc(owner, status);
        return found.stream().map(TaskResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public TaskResponse get(String username, Long id) {
        return TaskResponse.from(find(username, id));
    }

    public TaskResponse create(String username, TaskRequest req) {
        Task t = new Task();
        t.setOwner(owner(username));
        apply(t, req);
        Task saved = tasks.save(t);
        log.info("User '{}' created task {}", username, saved.getId());
        return TaskResponse.from(saved);
    }

    public TaskResponse update(String username, Long id, TaskRequest req) {
        Task t = find(username, id);
        apply(t, req);
        log.info("User '{}' updated task {}", username, id);
        return TaskResponse.from(tasks.save(t));
    }

    public void delete(String username, Long id) {
        tasks.delete(find(username, id));
        log.info("User '{}' deleted task {}", username, id);
    }

    private void apply(Task t, TaskRequest req) {
        t.setTitle(req.title().trim());
        t.setDescription(req.description());
        t.setStatus(req.status() != null ? req.status() : TaskStatus.TODO);
        t.setPriority(req.priority() != null ? req.priority() : Priority.MEDIUM);
        t.setDueDate(req.dueDate());
    }

    private User owner(String username) {
        return users.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    }

    private Task find(String username, Long id) {
        return tasks.findByIdAndOwner(id, owner(username))
                .orElseThrow(() -> new ResourceNotFoundException("Task " + id + " not found"));
    }
}
