package com.taskmanager.controller;

import com.taskmanager.dto.TaskRequest;
import com.taskmanager.dto.TaskResponse;
import com.taskmanager.model.TaskStatus;
import com.taskmanager.service.TaskService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final TaskService service;

    public TaskController(TaskService service) {
        this.service = service;
    }

    @GetMapping
    public List<TaskResponse> list(Principal principal,
                                   @RequestParam(required = false) TaskStatus status) {
        return service.list(principal.getName(), status);
    }

    @GetMapping("/{id}")
    public TaskResponse get(Principal principal, @PathVariable Long id) {
        return service.get(principal.getName(), id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TaskResponse create(Principal principal, @Valid @RequestBody TaskRequest req) {
        return service.create(principal.getName(), req);
    }

    @PutMapping("/{id}")
    public TaskResponse update(Principal principal, @PathVariable Long id,
                               @Valid @RequestBody TaskRequest req) {
        return service.update(principal.getName(), id, req);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(Principal principal, @PathVariable Long id) {
        service.delete(principal.getName(), id);
    }
}
