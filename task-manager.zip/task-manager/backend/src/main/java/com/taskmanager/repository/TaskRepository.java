package com.taskmanager.repository;

import com.taskmanager.model.Task;
import com.taskmanager.model.TaskStatus;
import com.taskmanager.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByOwnerOrderByCreatedAtDesc(User owner);
    List<Task> findByOwnerAndStatusOrderByCreatedAtDesc(User owner, TaskStatus status);
    Optional<Task> findByIdAndOwner(Long id, User owner);
}
