package com.taskmanager.dto;

import com.taskmanager.model.Priority;
import com.taskmanager.model.TaskStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

public record TaskRequest(
        @NotBlank @Size(max = 150) String title,
        @Size(max = 2000) String description,
        TaskStatus status,
        Priority priority,
        LocalDate dueDate) {
}
