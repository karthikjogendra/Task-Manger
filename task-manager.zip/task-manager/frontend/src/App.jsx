import { useEffect, useState } from 'react';
import AuthPage from './components/AuthPage.jsx';
import Board from './components/Board.jsx';
import { getUsername, setSession } from './api.js';

export default function App() {
  const [user, setUser] = useState(getUsername());

  useEffect(() => {
    const onExpired = () => setUser(null);
    window.addEventListener('session-expired', onExpired);
    return () => window.removeEventListener('session-expired', onExpired);
  }, []);

  function signOut() {
    setSession(null);
    setUser(null);
  }

  return user ? (
    <Board username={user} onSignOut={signOut} />
  ) : (
    <AuthPage onAuthenticated={setUser} />
  );
}
