const BASE = import.meta.env.VITE_API_URL || '/api';

let token = localStorage.getItem('token');

export function setSession(newToken, username) {
  token = newToken;
  if (newToken) {
    localStorage.setItem('token', newToken);
    localStorage.setItem('username', username);
  } else {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
  }
}

export const getUsername = () => (token ? localStorage.getItem('username') : null);

async function request(path, { method = 'GET', body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (res.status === 401 && token) {
    setSession(null);
    window.dispatchEvent(new Event('session-expired'));
  }
  if (res.status === 204) return null;

  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const detail = data?.errors ? Object.values(data.errors)[0] : null;
    throw new Error(detail || data?.message || `Request failed (${res.status})`);
  }
  return data;
}

export const api = {
  login: (username, password) => request('/auth/login', { method: 'POST', body: { username, password } }),
  register: (username, email, password) =>
    request('/auth/register', { method: 'POST', body: { username, email, password } }),
  listTasks: () => request('/tasks'),
  createTask: (task) => request('/tasks', { method: 'POST', body: task }),
  updateTask: (id, task) => request(`/tasks/${id}`, { method: 'PUT', body: task }),
  deleteTask: (id) => request(`/tasks/${id}`, { method: 'DELETE' }),
};
