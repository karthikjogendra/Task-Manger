import { useState } from 'react';
import TaskForm from './TaskForm.jsx';

const NEXT = {
  TODO: [{ to: 'IN_PROGRESS', label: 'Start' }],
  IN_PROGRESS: [{ to: 'DONE', label: 'Mark done' }, { to: 'TODO', label: 'Move back' }],
  DONE: [{ to: 'TODO', label: 'Reopen' }],
};
const PRIORITY_LABEL = { LOW: 'Low priority', MEDIUM: 'Medium priority', HIGH: 'High priority' };

function dueInfo(dueDate, status) {
  if (!dueDate) return null;
  const today = new Date().toISOString().slice(0, 10);
  const overdue = status !== 'DONE' && dueDate < today;
  const text = new Date(dueDate + 'T00:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  return { text: overdue ? `Overdue · ${text}` : `Due ${text}`, overdue };
}

export default function TaskCard({ task, onMove, onEdit, onDelete }) {
  const [editing, setEditing] = useState(false);
  const due = dueInfo(task.dueDate, task.status);

  if (editing) {
    return (
      <li className="card editing">
        <TaskForm
          initial={task}
          submitLabel="Save changes"
          onCancel={() => setEditing(false)}
          onSubmit={async (values) => {
            await onEdit(task, values);
            setEditing(false);
          }}
        />
      </li>
    );
  }

  return (
    <li className={`card p-${task.priority.toLowerCase()} ${task.status === 'DONE' ? 'done' : ''}`}>
      <h3>{task.title}</h3>
      {task.description && <p className="notes">{task.description}</p>}
      <p className="meta">
        <span>{PRIORITY_LABEL[task.priority]}</span>
        {due && <span className={due.overdue ? 'overdue' : ''}>{due.text}</span>}
      </p>
      <div className="card-actions">
        {NEXT[task.status].map((n) => (
          <button key={n.to} className="btn small" onClick={() => onMove(task, n.to)}>{n.label}</button>
        ))}
        <span className="spacer" />
        <button className="btn small ghost" onClick={() => setEditing(true)}>Edit</button>
        <button className="btn small ghost danger" onClick={() => onDelete(task)}>Delete</button>
      </div>
    </li>
  );
}
