import { useState } from 'react';

export default function TaskForm({ initial, submitLabel, onSubmit, onCancel }) {
  const [f, setF] = useState({
    title: initial?.title ?? '',
    description: initial?.description ?? '',
    priority: initial?.priority ?? 'MEDIUM',
    dueDate: initial?.dueDate ?? '',
  });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    if (!f.title.trim()) return;
    setBusy(true);
    try {
      await onSubmit({ ...f, title: f.title.trim(), dueDate: f.dueDate || null });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="task-form" onSubmit={submit}>
      <input
        className="title-input"
        placeholder="What needs doing?"
        value={f.title}
        onChange={set('title')}
        maxLength={150}
        autoFocus
        required
        aria-label="Task title"
      />
      <textarea
        placeholder="Notes (optional)"
        value={f.description}
        onChange={set('description')}
        rows={2}
        maxLength={2000}
        aria-label="Task notes"
      />
      <div className="form-row">
        <label>
          Priority
          <select value={f.priority} onChange={set('priority')}>
            <option value="LOW">Low</option>
            <option value="MEDIUM">Medium</option>
            <option value="HIGH">High</option>
          </select>
        </label>
        <label>
          Due date
          <input type="date" value={f.dueDate} onChange={set('dueDate')} />
        </label>
      </div>
      <div className="form-actions">
        <button className="btn primary" disabled={busy}>{submitLabel}</button>
        <button type="button" className="btn" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}
