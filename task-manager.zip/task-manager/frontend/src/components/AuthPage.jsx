import { useState } from 'react';
import { api, setSession } from '../api.js';

export default function AuthPage({ onAuthenticated }) {
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ username: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const isLogin = mode === 'login';
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const res = isLogin
        ? await api.login(form.username, form.password)
        : await api.register(form.username, form.email, form.password);
      setSession(res.token, res.username);
      onAuthenticated(res.username);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth">
      <section className="auth-intro">
        <h1>Taskboard</h1>
        <p>Keep work moving from to do, to in progress, to done.</p>
      </section>

      <form className="auth-card" onSubmit={submit}>
        <h2>{isLogin ? 'Sign in' : 'Create your account'}</h2>

        <label>
          Username
          <input value={form.username} onChange={set('username')} autoComplete="username" required minLength={3} />
        </label>
        {!isLogin && (
          <label>
            Email
            <input type="email" value={form.email} onChange={set('email')} autoComplete="email" required />
          </label>
        )}
        <label>
          Password
          <input
            type="password"
            value={form.password}
            onChange={set('password')}
            autoComplete={isLogin ? 'current-password' : 'new-password'}
            required
            minLength={6}
          />
        </label>

        {error && <p className="error" role="alert">{error}</p>}

        <button className="btn primary" disabled={busy}>
          {busy ? 'Please wait…' : isLogin ? 'Sign in' : 'Create account'}
        </button>

        <p className="switch">
          {isLogin ? 'New here?' : 'Already have an account?'}{' '}
          <button type="button" className="link" onClick={() => { setMode(isLogin ? 'register' : 'login'); setError(''); }}>
            {isLogin ? 'Create an account' : 'Sign in'}
          </button>
        </p>
      </form>
    </main>
  );
}
