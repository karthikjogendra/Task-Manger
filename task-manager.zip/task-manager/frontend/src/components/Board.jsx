import { useEffect, useState } from 'react';
import { api } from '../api.js';
import TaskCard from './TaskCard.jsx';
import TaskForm from './TaskForm.jsx';

const COLUMNS = [
  { key: 'TODO', label: 'To do', empty: 'Nothing waiting. Add a task to get started.' },
  { key: 'IN_PROGRESS', label: 'In progress', empty: 'Start a task and it will show up here.' },
  { key: 'DONE', label: 'Done', empty: 'Finished tasks will collect here.' },
];

export default function Board({ username, onSignOut }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [adding, setAdding] = useState(false);

  useEffect(() => {
    api.listTasks()
      .then(setTasks)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const toBody = (t, patch = {}) => ({
    title: t.title,
    description: t.description,
    priority: t.priority,
    status: t.status,
    dueDate: t.dueDate,
    ...patch,
  });
  const replace = (saved) => setTasks((all) => all.map((t) => (t.id === saved.id ? saved : t)));

  async function guard(fn) {
    setError('');
    try {
      await fn();
    } catch (e) {
      setError(e.message);
      throw e;
    }
  }

  const create = (values) =>
    guard(async () => {
      const saved = await api.createTask({ ...values, status: 'TODO' });
      setTasks((all) => [saved, ...all]);
      setAdding(false);
    });

  const move = (task, status) =>
    guard(async () => replace(await api.updateTask(task.id, toBody(task, { status })))).catch(() => {});

  const edit = (task, values) =>
    guard(async () => replace(await api.updateTask(task.id, toBody(task, values))));

  const remove = (task) => {
    if (!window.confirm(`Delete “${task.title}”?`)) return;
    guard(async () => {
      await api.deleteTask(task.id);
      setTasks((all) => all.filter((t) => t.id !== task.id));
    }).catch(() => {});
  };

  const open = tasks.filter((t) => t.status !== 'DONE').length;

  return (
    <div className="app">
      <header className="topbar">
        <div>
          <h1>Taskboard</h1>
          <p className="summary">
            {loading ? 'Loading your tasks…' : `${open} open · ${tasks.length - open} done`}
          </p>
        </div>
        <div className="topbar-actions">
          <button className="btn primary" onClick={() => setAdding(true)} disabled={adding}>New task</button>
          <button className="btn ghost" onClick={onSignOut}>Sign out ({username})</button>
        </div>
      </header>

      {error && <p className="error banner" role="alert">{error}</p>}

      {adding && (
        <div className="composer">
          <TaskForm submitLabel="Add task" onSubmit={create} onCancel={() => setAdding(false)} />
        </div>
      )}

      <main className="columns">
        {COLUMNS.map((col) => {
          const items = tasks.filter((t) => t.status === col.key);
          return (
            <section key={col.key} className="column" aria-label={col.label}>
              <h2>
                {col.label} <span className="count">{items.length}</span>
              </h2>
              {items.length === 0 && !loading ? (
                <p className="empty">{col.empty}</p>
              ) : (
                <ul>
                  {items.map((t) => (
                    <TaskCard key={t.id} task={t} onMove={move} onEdit={edit} onDelete={remove} />
                  ))}
                </ul>
              )}
            </section>
          );
        })}
      </main>
    </div>
  );
}
