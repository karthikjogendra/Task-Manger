# Cloud-Based Task Management System with Automated CI/CD

A web-based task manager with a Spring Boot REST API, a React frontend, MySQL storage, a Jenkins CI/CD pipeline, Docker containers, and deployment to AWS EC2.

```
Developer ──push──▶ GitHub ──webhook──▶ Jenkins
                                           │ 1. checkout
                                           │ 2. mvn verify (JUnit) + npm build   (parallel)
                                           │ 3. docker build (backend, frontend)
                                           │ 4. docker push  (Docker Hub)
                                           ▼ 5. ssh → docker compose pull && up -d
                                       AWS EC2 ───────────────────────────────┐
                                        ┌ nginx + React (port 80) ──/api──▶ Spring Boot (8080) ──▶ MySQL (3306)
                                        └ everything runs as Docker containers on one compose network
```

## Features

| Area | What is included |
|------|------------------|
| REST API | CRUD for tasks, filtering by status, validation, consistent JSON errors |
| Auth | Register and login, BCrypt password hashing, stateless JWT, per-user data isolation |
| Frontend | React (Vite) board with To do / In progress / Done columns, inline edit, priorities, due dates, overdue highlighting, responsive layout |
| Database | MySQL 8 via Spring Data JPA (tables are created automatically) |
| CI/CD | Jenkins declarative pipeline triggered by GitHub pushes |
| Containers | Multi-stage Dockerfiles for backend and frontend, Docker Compose for the whole stack |
| Logging | SLF4J/Logback to console and rolling files (`/app/logs`, 14 days, 500 MB cap) |
| Monitoring | Spring Actuator: `/actuator/health`, `/info`, `/metrics`, `/prometheus`; container healthchecks |

## Project layout

```
task-manager/
├── backend/            Spring Boot 3 (Java 17), Maven, Dockerfile, JUnit tests
├── frontend/           React + Vite, nginx.conf, Dockerfile
├── docker-compose.yml  MySQL + backend + frontend
├── Jenkinsfile         CI/CD pipeline
└── .env.example        Secrets template
```

## Run locally with Docker (easiest)

```bash
cp .env.example .env        # then edit the values
docker compose up --build
```

Open http://localhost, create an account, and add tasks.

## Run locally without Docker

Prerequisites: JDK 17, Maven 3.9+, Node 20+, MySQL 8 running locally.

```bash
# Terminal 1: backend (defaults connect to localhost:3306 as root/root; override with env vars)
cd backend
mvn spring-boot:run

# Terminal 2: frontend (dev server proxies /api to localhost:8080)
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. Environment variables for the backend: `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `JWT_SECRET` (32+ characters), `CORS_ORIGINS`.

Run the tests (uses in-memory H2, no MySQL needed): `cd backend && mvn test`

## REST API

All `/api/tasks` calls need the header `Authorization: Bearer <token>`.

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | `{username, email, password}` returns `{token, username}` |
| POST | `/api/auth/login` | `{username, password}` returns `{token, username}` |
| GET | `/api/tasks?status=TODO` | List your tasks (`status` is optional) |
| GET | `/api/tasks/{id}` | Get one task |
| POST | `/api/tasks` | Create: `{title, description?, priority?, status?, dueDate?}` |
| PUT | `/api/tasks/{id}` | Update a task |
| DELETE | `/api/tasks/{id}` | Delete a task (204) |

`status`: `TODO`, `IN_PROGRESS`, `DONE`. `priority`: `LOW`, `MEDIUM`, `HIGH`. `dueDate`: `YYYY-MM-DD`.

Try it:

```bash
TOKEN=$(curl -s -X POST localhost/api/auth/register -H 'Content-Type: application/json' \
  -d '{"username":"demo","email":"demo@example.com","password":"secret123"}' | sed 's/.*"token":"\([^"]*\)".*/\1/')
curl -s -X POST localhost/api/tasks -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"title":"Ship it","priority":"HIGH"}'
```

## Deploy on AWS EC2

1. **Launch an instance**: Ubuntu 22.04/24.04, t3.small or larger (MySQL + Spring Boot need about 2 GB RAM). Security group inbound rules: **22** (SSH, restrict to your IP), **80** (HTTP). Do not open 3306 or 8080.
2. **Install Docker** on the instance:
   ```bash
   sudo apt update && sudo apt install -y docker.io docker-compose-v2
   sudo usermod -aG docker ubuntu     # log out and back in afterwards
   ```
3. **Manual first deploy (optional)**: copy the project (or just `docker-compose.yml` plus a `.env`) to the server and run `docker compose up -d --build`.
4. Visit `http://<EC2-public-IP>`.

For HTTPS, put a domain in front (Route 53) and add a TLS terminator such as an ALB with ACM, or Caddy/Certbot on the instance.

## Jenkins CI/CD setup

1. **Jenkins server** (can be a second EC2 instance): install JDK 17, Maven, Node 20, Docker, and add the `jenkins` user to the `docker` group.
2. **Plugins**: Pipeline, Git, GitHub, JUnit, SSH Agent.
3. **Credentials** (Manage Jenkins → Credentials):
   - `dockerhub-creds`: Docker Hub username and access token
   - `ec2-ssh-key`: SSH private key for the EC2 instance
   - `taskmanager-env`: Secret file containing the production `.env` (copy `.env.example`, set strong values)
4. **Edit the `Jenkinsfile`**: set `DOCKER_USER` and `EC2_HOST`.
5. **Create the job**: New Item → *Multibranch Pipeline* (or Pipeline from SCM) pointing at your GitHub repo.
6. **GitHub webhook**: repo Settings → Webhooks → `http://<jenkins-host>:8080/github-webhook/` (content type `application/json`, push events).

Every push builds and tests. Pushes to `main` also push images and deploy to EC2, then run a health-check smoke test.

## Logging and monitoring

- View container logs: `docker compose logs -f backend`
- Log files are kept in the `backend-logs` volume (`/app/logs/task-manager.log`).
- Health: `curl http://<host>/actuator/health`
- Metrics and Prometheus scraping need authentication and are not exposed through nginx. Reach them from the server on the backend container, or add a Prometheus/Grafana service to the compose file.
- Optional upgrade: ship logs and metrics to AWS CloudWatch with the CloudWatch agent.

## Security notes

- Always set a strong `JWT_SECRET` and `DB_PASSWORD` in production; the defaults are for local use only.
- Hibernate `ddl-auto: update` is convenient for a project; use Flyway or Liquibase migrations for production systems.
- The JWT is stored in `localStorage` for simplicity. For stricter security, use httpOnly cookies.

## Tech stack

Java 17, Spring Boot 3.2 (Web, Security, Data JPA, Validation, Actuator), MySQL 8, JJWT, React 18, Vite, nginx, Git/GitHub, Jenkins, Docker, Docker Compose, AWS EC2.
